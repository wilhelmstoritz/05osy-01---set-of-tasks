# Green Threads - Preemptive Threads in User Space.

Program simulates preemptive switching of threads in user space. 
Program was inspired by [Green Threads](https://c9x.me/articles/gthreads/code0.html).
Original code is available at [GitHub](https://github.com/mpu/gthreads/tree/code0).

To build program use command `make`.
