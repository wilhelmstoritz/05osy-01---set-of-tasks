# FreeRTOS Example for Linux

FreeRTOS [Pocket Guide](https://github.com/osy-cs/osy-freertos-posix/blob/main/FreeRTOS-PockGui.md).

This program example use [Posix/Linux Simulator](https://freertos.org/FreeRTOS-simulator-for-Linux.html).

**Build and run**

```
  $ cd posix-demo
  $ make
  $ ./build/posix-demo-main
```
